# Bird dataset > 2024-07-04 9:22am
https://universe.roboflow.com/mahbub/bird-dataset-eoizo

Provided by a Roboflow user
License: CC BY 4.0

