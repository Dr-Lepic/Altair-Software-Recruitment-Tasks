#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist

def move_circle(pub):
    rate = rospy.Rate(1)
    twist = Twist()
    twist.linear.x = 2.0
    twist.angular.z = 1.0

    for _ in range(10):
        pub.publish(twist)
        rate.sleep()

def move_square(pub):
    rate = rospy.Rate(1)
    twist = Twist()

    for _ in range(4):
        twist.linear.x = 2.0
        twist.angular.z = 0.0
        pub.publish(twist)
        rate.sleep()

        twist.linear.x = 0.0
        twist.angular.z = 1.57  # 90 degrees in radians
        pub.publish(twist)
        rate.sleep()

def move_spiral(pub):
    rate = rospy.Rate(1)
    twist = Twist()
    twist.linear.x = 0.01
    twist.angular.z = 1.00

    for i in range(100):
        twist.linear.x += 0.10
        pub.publish(twist)
        rate.sleep()

def main():
    rospy.init_node('turtle_movement', anonymous=True)
    pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)

    print("Enter a command (A: Circle, B: Square, C: Spiral): ")
    command = input().upper()

    if command == 'A':
        move_circle(pub)
    elif command == 'B':
        move_square(pub)
    elif command == 'C':
        move_spiral(pub)
    else:
        print("Invalid command!")

    twist = Twist()  # Stop the turtle bot
    pub.publish(twist)

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass

