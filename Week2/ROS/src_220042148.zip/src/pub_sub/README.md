pub_sub is a basic ROS project where 
the publisher node publishes {"Hello World"} message and 
the subscriber node will listen to it and display it.

used (https://wiki.ros.org/ROS/Tutorials/WritingPublisherSubscriber%28python%29) for the source
code and updated/adjusted the code according to my need(based on my research).
